mh = {initialPlay:true};

////////////////////////////////////////////////////////////////////////////////////////////////////

mh.listen = function(ev) {
	var data = ev.data;
	var ci,video,player = mh._player,trIdx;

    if(!mh.video) {
        mh.video = document.getElementById('video_player_tag');
    }
	
//	if(mh.video.focus) {
//		mh.video.focus();
//	}

//	console.error('********************* RECEIVED ' , ev.data);
	if(data.op === 'init') {
		mh.ci = data.cfg;
		mh._player = window.mp.createVODPlayer(mh.video, mh.ci);
		mh._player.on('changeDuration',mh.onPlayerReady);
		
		mh.video.addEventListener("playing", mh.reportPlay, false);
		document.addEventListener("click", mh.reportTap, false);
		mh.initialPlay = true;

		//mh._player.on('changePlayState',function(arg) {
		//	console.error('ZONE Player changePlayState:'+arg.data.type);
		//});

		return;
	} else if(data.op === 'play') {
		if(mh._ready) {
			if(player.state.indexOf('play') === -1) { //NOT 'play' or 'playing'
				player.trigger('changePlay');
				if(mh.initialPlay)
					mh.sendInitialPlay();
			}
		} else {
			mh._delayedAutoPlay = true
		}
		return;
	} else if(data.op === 'changeTrack') {
		trIdx = data.ti -1;
		
		if(mh._ready) {
			if(mh.initialPlay)
				mh.sendInitialPlay();

			player.playByIndex(trIdx);//%%INFO data.ti == track index
		} else {
			mh._delayedTC = trIdx;
			mh._delayedAutoPlay = true
		}
		return;
	} 
	
	if(!player || !mh._ready) {
		console.error('mediaPlayer NOT ready');
		return;
	}
	
	if(data.op === 'pause') {
		if(player.state.indexOf('play') !== -1)
			player.trigger('changePlay');
	} else if(data.op === 'resume') {
		if(player.state.indexOf('play') === -1)
			player.trigger('changePlay');
	} else if(data.op === 'stop') {
		//if(player.state.indexOf('play') !== -1)
			player.trigger('stop');
	} else if(data.op === 'seek') {
		player.needReport = true;
		player.trigger('seek',{time:data.time});
	} else if(data.op === 'setSubtitle') {
		player.setTrack(data.type);
	} else if(data.op === 'showSubtitle') {
		if(data.show === true) {
			if(mh._player.controller && mh._player.controller.subtitlesButton && mh._player.controller.subtitlesButton.hideSubtitles) {
				mh._player.controller.subtitlesButton.showSubtitles();
			}
		} if(data.show === false) {
			if(mh._player.controller && mh._player.controller.subtitlesButton && mh._player.controller.subtitlesButton.hideSubtitles) {
				mh._player.controller.subtitlesButton.hideSubtitles();
			}
		}
	}
}

mh.onPlayerReady = function (arg) {
	mh._ready = true;

	mh.addEventReporters(mh._player);
	
	if(mh._delayedAutoPlay) {
//		console.error('HANDLED _delayedAutoPlay');
		if(mh.initialPlay)
			mh.sendInitialPlay();
		if(mh._delayedTC) {
			mh._player.playByIndex(mh._delayedTC);//%%INFO data.ti == track index
			mh._delayedTC = undefined;
		} else if(mh._player.state.indexOf('play') === -1) {
			mh._player.trigger('changePlay');
		}
		mh._delayedAutoPlay = false;
	}

	var duration = mh._player.element?mh._player.element.duration:0;
	
	if(window.parent)
		window.parent.postMessage({op:'zone_ready',est:duration},'*');

	arg.removeListener();
}

mh.sendInitialPlay = function() {
	mh.initialPlay = false;
	
	var duration = mh._player.element?mh._player.element.duration:0;
	if(window.parent)
		window.parent.postMessage({op:'zone_initial_play',est:duration},'*');	
}

mh.addEventReporters = function(player) {
	player.on('end', function(arg) {
		mh.initialPlay = true; //%% 끝에 도달하면 시간보고 다시함.
		if(window.parent)
			window.parent.postMessage({op:'zone_onend'},'*');
	});

	player.on('seeked', function(arg) {
		if(!player.needReport)
			return;
		
		player.needReport = false;

		if(window.parent)
			window.parent.postMessage({op:'zone_seeked'},'*');
		else
			console.error('window.parent NOT found');
	});
	
	player.on('changedResource', function(arg) {
		console.error('zone_tc:' + (arg.data.nIndex+1));
		if(window.parent)
			window.parent.postMessage({op:'zone_tc',ti:((arg && arg.data)?(arg.data.nIndex+1):'-1')},'*');
	});
	
	//player.on('changeSubtitlesState', function(arg) {
	//	console.error('changeSubtitlesState cb:' , arg);
	//});
}

mp.dom.onReady(function() {
	var os = getMobileOperatingSystem();
	if (os ==='Android' || os === 'iOS' || os === 'Chrome on iOS'){
            function evScreen(ev)
            {
                ev.preventDefault();
            }
            //실 환경에서는 top.bx를 찾을 수 없다.
                window.addEventListener('touchmove',evScreen,false);
            if (os === 'iOS' || os === 'Chrome on iOS' ){
//                top.bx.Event.add(window, 'touchstart', evScreen, false);
//                top.bx.Event.add(window, 'touchend', evScreen, false);
            }
        }
	window.addEventListener("message", mh.listen, false);
});

/**
 * Determine the mobile operating system.
 * This function returns one of 'iOS', 'Android', 'Windows Phone', or 'unknown'.
 *
 * @returns {String}
 */
function getMobileOperatingSystem() {
  var userAgent = navigator.userAgent || navigator.vendor || window.opera;

      // Windows Phone must come first because its UA also contains "Android"
    if (/windows phone/i.test(userAgent)) {
        return "Windows Phone";
    }

    if (/android/i.test(userAgent)) {
        return "Android";
    }

    // iOS detection from: http://stackoverflow.com/a/9039885/177710
    if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
		if(userAgent.match('CriOS'))
			return "Chrome on iOS";
        return "iOS";
    }

    return null;
}

mh.reportPlay = function(ev) {
	if(window.parent)
		window.parent.postMessage({op:'zone_played'},'*');
}

mh.reportTap = function(ev) {
	if(window.parent)
		window.parent.postMessage({op:'zone_tapped'},'*');
}