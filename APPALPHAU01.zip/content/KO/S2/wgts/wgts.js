///////////////////////////////////////////////////////////////////////////////
// ebs.wgt.video
/*
 *  event:
 *  TCD:TrackChangeDetected
 *  RPT_TIME : ReportUsageTime
 *
 *  state:
 *  PT:PlayTrack
 *
 *  TODO:
 *  혹시 multiple instance를 지원해야 하면, xa.properties에 getConfig결과를 넣고 objData마다 저장/로드하게 해야 함.
 */

var xa = {}

xa.APX_NO_POINTER_EV = true;

//help 정보
xa.scriptInfo = {
    wgtRun:{seek:{param:"{time:integer}''", help:"Seek video to 'time' seconds ''."}}
};

xa.styleMap = {
	title:true
	,visibility:true
	,alpha:true
	,angle:true
}

xa.editor = {
	iconThumb:'imgs/wgts/thumbs/video.png'
	,properties:{
	//	'Control':['Show', 'Hide']
	}
	,states:{play:'Play', stop:'Stop', resume:'Resume', pause:'Pause',end:'End'}
}

xa.properties = {
	state:'stop', //initial state
	uiOpened:false,
	pauseOnHidden:true,
	attrs:{
		apxMediaControl:false, /* 외부에서 exeMedia 류의 함수들을 호출하게 하려면 true, 아니면 false */ Control:'Hide'
		,mi: undefined
		//[ //비디오 소스 복수 허용.
		//	{
		//		subtitle_en:{size:0, data:'',name:''}
		//		,subtitle_ko:{size:0, data:'',name:''}
		//		,media_index: -1
		//		,test_url:'http://'
		//	}
		//]
	}
};

xa.CMedia = {
	btnPlay:'DB/ux/imgs/wgts/youtube_play_btn.png'
	,bgColor:'#000000'
	,control:{Show:{btnPlay:true, systemControl:true}, Hide:{btnPlay:true}}
}

xa._getConfig = function(apx,oId,/* properties.attrs.mi */mi,cfg) {
//mi.media_index,mi.test_url,apx.attachmentURL(oId, 'subtitle_en.smi'),apx.attachmentURL(oId, 'subtitle_ko.smi')
	var mp_cfg = {
		controllers : null
		,controllersAutoHide : true
		,controllerHideDelay : 3
		,skin: cfg.skin
		,volume : 1
		,speedRates : [0.6,0.8,1.0, 1.2, 1.5, 2.0] 
		,volumeSliderType : 1
        ,speedLabelText:''
		,sources : [
			//{
			//src : video_url
			//track:[trackElement1,trackElement2];
			//},
		]
	};
	
	var chomokdal_controllers =  { //UI 관련 태그들이 이 구조의 attribute 순서에 따라 생성됨.
//			osdPlayButton 	: true,		
			playButton 		: true,
			timeSlider 		: true,		
			currentTime 	: true,
			durationTime 	: true,
			speedDownButton : true,		
			currentSpeed 	: true,
			speedUpButton 	: true,
			fullscreenButton: true,
			volumeButton 	: true,
			volumeSlider 	: true,
			subtitlesButton : true,		
			languageButton 	: true
			}
	var sang_controllers = {
			osdPlayButton 	: true,		
			playButton 		: true,
			timeSlider 		: true,		
			currentTime 	: true,
			durationTime 	: true,
			speedDownButton : true,		
			currentSpeed 	: true,
			speedUpButton 	: true,
			languageButton 	: true,
			subtitlesButton : true,
			fullscreenButton: true,//place holder로 사용.			
			volumeButton 	: true,
			volumeSlider 	: true
			};
	
    if(cfg.skin.indexOf('chomokdal') === 0)
        mp_cfg.controllers = chomokdal_controllers;
	else if(cfg.skin.indexOf('sang') === 0)
        mp_cfg.controllers = sang_controllers;
	
	var i, video_url;
			
	for(i = 0; i < mi.length;i++) {
		var track = [
				{
					kind 	: 'subtitles'
					,label 	:  undefined /*'영어' ||'한국어' */
					,srclang : undefined /* 'en' || 'ko' */
					,type 	: 'smi'
					,src 	: undefined /* var subtitle_en || subtitle_ko */
				},{
					kind 	: 'subtitles'
					,label 	:  undefined /*'영어' ||'한국어' */
					,srclang : undefined /* 'en' || 'ko' */
					,type 	: 'smi'
					,src 	: undefined /* var subtitle_en || subtitle_ko */
				}];
		
		mp_cfg.sources[i] = {};
		
		video_url = mi[i].test_url?mi[i].test_url:'';

		if(window.ebs_if && !(window.top && window.top.getVodSrc)) {
			video_url = mi[i].test_url?mi[i].test_url:'';
		} else if (window.ebs_if){
			video_url = ebs_if.getVideoPath({index:mi[i].media_index});
			//console.error(i+'th ebs_if.getVideoPath returns:' + video_url);
			if(!video_url)
				video_url = mi[i].test_url;
		} else {
			console.error('ebs.wgt.video: ebs_if NOT found');
		}
	
		if(mi[i].subtitle_en && mi[i].subtitle_en.data && mi[i].subtitle_en.data.length) {
			track[0].src = this._basePath + '/' + apx.attachmentURL(oId, mi[i].subtitle_en.name);
			track[0].label = 'ENG';
			track[0].srclang = 'en';
		}

		if(mi[i].subtitle_ko && mi[i].subtitle_ko.data && mi[i].subtitle_ko.data.length) {
			track[1].src = this._basePath + '/' + apx.attachmentURL(oId, mi[i].subtitle_ko.name);
			track[1].label = 'KOR';
			track[1].srclang = 'ko';
		}

        for(var j = 0; j < track.length; j++) {
			if(!track[j].src) {
					track.splice(j,1);
					j--;
			}
        }

		mp_cfg.sources[i].src = video_url;
		if(track.length)
			mp_cfg.sources[i].track = track;
	}

	return mp_cfg;
}

xa._command = []; //command history

xa.pubOnGetAttachment = function(prj, pId, oId)
{
	var ret = [];
	var i;
	var mi = prj.pages[pId].objects[oId].create.data.properties.attrs.mi;

	for(i = 0; i < mi.length;i++) {
		if (mi[i] && mi[i].subtitle_en && mi[i].subtitle_en.data && mi[i].subtitle_en.name){
			ret.push({name:mi[i].subtitle_en.name,data:mi[i].subtitle_en.data});
		}
	
		if (mi[i] && mi[i].subtitle_ko && mi[i].subtitle_ko.data && mi[i].subtitle_ko.name){
			ret.push({name:mi[i].subtitle_ko.name,data:mi[i].subtitle_ko.data});
		}
	}

	if(ret.length)
		return ret;
	return null;
}

xa.exeCreateTag = function(viewer, canvas, objData, zx, zy)/*Element*/
{
	var path = window.location.href;
	if(path.lastIndexOf("/exe/") !== -1) {
		path = path.substring(0, path.lastIndexOf("/exe/"));
	}
	else {
		path = path.substring(0, path.lastIndexOf("/"));
	}

	if(window.apd) {//편집 환경
		this.mpLocation = path + '\/DB\/ebs\/apx\/lib\/zone_player\/mediaplayer_v1.1.42.ebs.js';
		this.mhLocation = path + '\/DB\/ebs\/apx\/ebs.wgt.video\/message_handler.js';
	} else {
		this.mpLocation = "http:\/\/www.ebslang.co.kr\/mobilecontent\/mediaplayer_v1.1.42.ebs.js";
		this.mhLocation = path + '\/wgts\/ebs.wgt.video\/message_handler.js';
	}

	if(window.location.href.lastIndexOf("/exe/") !== -1) {
		this.mpLocation = path + '\/exe\/zone_player\/mediaplayer_v1.1.42.ebs.js';
	}
	
	this._basePath = path;

	var tag = apn.widgets['apn.wgt.rect'].exeCreateTag.call(this,viewer, canvas, objData, zx, zy);
	
	return tag;
}

/*
 * zone player 1.42는 windows 10 ie11에서 iframe에 border가 없으면 비디오 화면 백화 현상 발생.(UI는 정상 표시됨)
 */
xa.writeHTMLasJS = function(wnd,mpLoc,mhLoc){
	wnd.document.open();
    wnd.document.write("<!DOCTYPE html>");
	wnd.document.write("<html style='width:100%;height:100%'>");
	wnd.document.write("<head>");
	wnd.document.write("<meta charset=\"utf-8\">");
	wnd.document.write("<meta http-equiv=\"Content-Type\" content=\"text\/html; charset=utf-8\">");
	wnd.document.write("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no\">");
	wnd.document.write("<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">");	
	wnd.document.write("<link rel='stylesheet' type='text/css' href='http://www.ebslang.co.kr/mobilecontent/chomokdal_hangul_font.css'/>");
	wnd.document.write("<script src=\"" + mpLoc + "\" type=\"text\/javascript\"><\/script>");
	wnd.document.write("<script src=\"" + mhLoc + "\" type=\"text\/javascript\"><\/script>");
	wnd.document.write("<\/head>");
	//wnd.document.write("<body style='margin:0;border:1px solid transparent;font-size:50px;width:100%;height:100%;overflow:hidden;'>");
	wnd.document.write("<body style='margin:0;border:0px;font-size:50px;width:100%;height:100%;overflow:hidden;'>");
	wnd.document.write("<video playsinline webkit-playsinline id=\"video_player_tag\"><\/video>");
	wnd.document.write("<\/body>");
	wnd.document.write("<\/html>");
	wnd.document.close();
}

xa.exeRenderTag = apn.widgets['apn.wgt.rect'].exeRenderTag;
xa.createAsCanvasObject = apn.widgets['apn.wgt.audio'].createAsCanvasObject;

xa.exeSetState = function(apx, tag, /*String*/state, prvStart, byStart)/*undefined|null*/
{
	if (state){
		//%%INFO Async로 Player가 생성되므로 Autoplay start 기능을 위해서 별도 개발함
		if (state == 'play') {
			if(!this._ready){
				tag._delayedAutoPlay = true;
			} else
			{
				if(this.win && this.config) {
					this.win.postMessage({op:'play'},this._basePath);
				}
			}
		} else if(state.indexOf('PT_') !== -1) {
			if(!this._ready){
				tag._delayedAutoPlay = true;
				tag._delayedTC = state.split('_')[1];
			} else
			{
				if(this.win && this.config) {
					this.win.postMessage({op:'changeTrack',ti:state.split('_')[1]},this._basePath);
				}
			}
		} else if(state.indexOf('stop') !== -1) {
			if(this.win)
				this.win.postMessage({op:'stop'},this._basePath);
		} else if(state.indexOf('pause') !== -1) {
			if(this.win)
				this.win.postMessage({op:'pause'},this._basePath);
		} else if(state.indexOf('resume') !== -1) {
			if(this.win)
				this.win.postMessage({op:'resume'},this._basePath);
		}
	}
}

xa.exeOnLoad = function(apx, oId)
{
	var tag = apx.wgtTag(oId);

/* IFRAME에선 필요없음. 오히려 하단에 빈칸 생김
	var fr,objData;
	try {
		objData = apx.screen.objects[oId];
		fr = objData.init.shape.w/1280;
	} catch (e) {
		fr = 1;
		console.error('exeOnLoad: not found objData');
	}
	
	//w 1280/font-size 50px를 기준으로 조절.
	tag.style.backgroundColor = '#000000';
	tag.style.fontSize = Math.round(50*fr*(1/apx.getZoomY())) + 'px';
*/

	tag._tagBlock = tag.$TAG('DIV', {style:'position:absolute;left:0px;top:0px;width:100%;height:100%;z-index:1;display:none;'});

    var _this = this;

    function onSeek(changeWgtId, value)
    {
        if (changeWgtId == oId && _this._ready && _this.win){
			_this.win.postMessage({op:'seek',time:value},'*');
		}
	}
	apx.wgtListenProperty(oId, 'seek', onSeek);
	
    function onChangeSubtitle(changeWgtId, value)
    {
        if (changeWgtId == oId && _this._ready && _this.win){
			
			if((/en/i).test(value))
				value = 0;
			else if((/ko/i).test(value))
				value = 1;
			
			if(value === 0 || value === 1)
				_this.win.postMessage({op:'setSubtitle',type:value},'*');
			else
				console.error('setSubtitle err: ' + value);
		}
	}

	apx.wgtListenProperty(oId, 'setSubtitle', onChangeSubtitle);
	
    function onSubtitleVisibility(changeWgtId, value)
    {
        if (changeWgtId == oId && _this._ready && _this.win){
			if(value === true || value === false)
				_this.win.postMessage({op:'showSubtitle',show:value},'*');
			else
				console.error('showSubtitle err: ' + value);
		}
	}

	apx.wgtListenProperty(oId, 'showSubtitle', onSubtitleVisibility);

}

xa.exeOnStart = function(apx, oId)
{
	var tag = apx.wgtTag(oId);
	var _this = this;

	if(this.wrapper)
	{
		console.error('ebs.wgt.video: IFRAME exists.');
		return;
	}
	
	this.wrapper = tag.$TAG('IFRAME', {scrolling:scroll?'auto':'no', style:'position:absolute;left:0px;top:0px;width:100%;height:100%;border:none;overflow:hidden;'});
	//var objData = apx.screen.objects[oId];

	//전체 콘텐츠를 풀스크린으로 돌릴 수 있기 때문에 비디오 풀스크린은 막아도 되며, 비디오의 풀스크린 동작이 aspen 풀스크린 동작과 충돌할 수 있음.
	//this.wrapper.setAttribute('allowFullScreen', '');

	this.win = this.wrapper.contentWindow;

	this.childMessageHandler = function(ev) {
		var op = ev.data.op;
		if(!window.ebsWgtVideo) {
			console.error('window.ebsWgtVideo Not found');
			return;
		}

		if(op === 'zone_ready') {
			_this._ready = true;
			ebsWgtVideo._duration = ev.data.est;

			if(tag._delayedAutoPlay) {
				if(tag._delayedTC) {
					if(_this.win && _this.config) {
						_this.win.postMessage({op:'changeTrack',ti:tag._delayedTC},_this._basePath);
					}
					tag._delayedTC = undefined;
				}
				else {
					_this.win.postMessage({op:'play'},"*");
				}
				tag._delayedAutoPlay = false;
				//console.error('_delayedAutoPlay');
			}
		} else if( op === 'zone_seeked') {
			//seek의 결과 통보 이벤트로 wgtEvent를 써보자.
			//console.error('Seeked ' + ev.data.cnt);
			apx.fireEvent('wgtEvent', 'Seeked', oId);
		} else if( op === 'zone_onend') {
			//console.error('ON_END received');
			clearInterval(ebsWgtVideo._reportTimer);
			ebsWgtVideo._reportTimer = null;
			ebsWgtVideo._reportUsage(true);
			apx.fireEvent('wgtEvent', 'End', oId);
		} else if(op === 'zone_tc') {//track changed
			//console.error('received TCD_'+ev.data.ti);
			apx.fireEvent('wgtEvent', 'TCD_'+ev.data.ti, oId);
		} else if(op === 'zone_initial_play') {
			if(ebsWgtVideo._reportTimer !== null)
				clearInterval(ebsWgtVideo._reportUsage);

			if(ebsWgtVideo._duration !== ev.data.est)
				console.error('ready duration:' + ebsWgtVideo._duration + ' initial play duration:' + ev.data.est);

			ebsWgtVideo._duration = ev.data.est;
			ebsWgtVideo._lastReportTime = (new Date()).getTime();
			ebsWgtVideo._reportTimer = setInterval(ebsWgtVideo._reportUsage,_this.reportInterval);
		} else if(op === 'report_time') { //%%INFO 현재 사용하지 않음.
			//console.error('est:' + ev.data.est + ' rt:' + ev.data.rt);
			apx.ctxSet('zone_time_report',{est:ev.data.est,rt:ev.data.rt});
			apx.fireEvent('wgtEvent', 'RPT_TIME', oId);
		} else if(op === 'zone_played') {
			apx.fireEvent('wgtEvent', 'Played', oId);
		} else if(op === 'zone_tapped') {
			apx.fireEvent('wgtEvent', 'Tapped', oId);
		}
	}

	window.addEventListener('message', this.childMessageHandler);

	this.reportInterval = 120000;//2분 간격
	this.onLoadIFrame = function()
	{
		var mi = apx.wgtGetProperty(oId, 'mi');
		
		var cfg = apx.wgtGetProperty(oId, 'p_cfg') || {skin:'chomokdal'}; //기존에 만들어둔 콘텐츠는 p_cfg가 없음.
		
		var userAgent = navigator.userAgent || navigator.vendor || window.opera;

		_this.config = _this._getConfig(apx,oId,mi,cfg);
		if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
			_this.config.skin = cfg.skin + '_ios';
		}
		_this.win.postMessage({op:'init',cfg:_this.config},_this._basePath);
	}

	this.wrapper.addEventListener("load", this.onLoadIFrame, false);

	this.writeHTMLasJS(this.win,this.mpLocation,this.mhLocation);
}

xa._reportUsage = function(isFinal) {
	var c_rt;
	if(isFinal) {
		c_rt = ((new Date()).getTime() - ebsWgtVideo._lastReportTime)/1000;
	} else {
		c_rt = ebsWgtVideo.reportInterval/1000;
	}
	
	if (window.ebs_if){
		ebsWgtVideo._lastReportTime = (new Date()).getTime();
		ebs_if.setMovierunTime({est:ebsWgtVideo._duration,rt:c_rt});
	}
}

/*
 * 페이지가 드래그 될때(bookmode 실행기) 위젯을 가리는 장막 태그를 on/off시킴. (iframe이 이벤트를 먹어버리는 문제 대응)
 */
xa.exeOnScreenDrag = function(apx, oId, /*Boolean*/start)
{
	var tag = apx.wgtTag(oId);

	if (start){
		if (tag._tagBlock) tag._tagBlock.style.display = 'block';
	}
	else{ //end
		if (tag._tagBlock) tag._tagBlock.style.display = 'none';
	}
}

xa.exeOnPause = function(apx, /*ID*/oId)
{
	console.error('exeOnPause');
	if(this._ready)
		this.win.postMessage({op:'pause'},this._basePath);	
}

xa.exeOnResume = function(apx, /*ID*/oId)
{
	console.error('exeOnResume');
	if(this._ready)
		this.win.postMessage({op:'resume'},this._basePath);	
}

xa.exeOnDestroy = function(apx, /*ID*/oId)
{
	//console.error('exeOnDestroy');
	var tag = apx.wgtTag(oId);
	
	clearInterval(ebsWgtVideo._reportTimer);
	ebsWgtVideo._reportTimer = null;
	
	window.removeEventListener('message', this.childMessageHandler);

	if(this.wrapper) {
		this.wrapper.removeEventListener("load", this.onLoadIFrame);
		this.wrapper.src = 'about:blank';
		tag.removeChild(this.wrapper);		
	}

	this.onLoadIFrame = this.childMessageHandler = null;
	
	this._ready = false;
	this.wrapper = null;
	this.win = null;
}

xa.exeOnScreenVisibility = function(apx, oId, state)
{
	if(!apx.wgtGetProperty(oId,'pauseOnHidden'))
		return;
	
	if (state == 'visible'){
	// Resume action		
	}
	else if (state == 'hidden'){
	// Pause action
		if(this._ready && this.win && this.config) {
				this.win.postMessage({op:'pause'},this._basePath);
		}
	}
}

xa.exeMediaPlay = function(tag, /*Boolean*/fromStart, /*Number|undefined*/track)
{
	var _this = this;
	
	if(this._ready) {
		if(this.win && this.config) {
			this.win.postMessage({op:'play'},this._basePath);
		}
	} else {
	}
}

xa.exeMediaPause = function(tag)
{
	if(this._ready) 
		this.win.postMessage({op:'pause'},this._basePath);
}

xa.exeMediaStop = function(tag, _apx)
{
	if(this._ready)
		this.win.postMessage({op:'stop'},this._basePath);
}

xa.edtOnConfig = function(/*CEditor*/apd, objID)
{
	var mi = apd.wgtGetProperty(objID, 'mi');
	var cfg = apd.wgtGetProperty(objID, 'p_cfg');
	var tagDlg;
	
	mi = mi || [ //비디오 소스가 복수개가 될 수 있음.
			{
				subtitle_en:{size:0, data:'',name:''}
				,subtitle_ko:{size:0, data:'',name:''}
				,media_index: -1
				,test_url:'http://'
			}
		];

	cfg = cfg || {skin:'chomokdal'};

	function onOK()
	{
		eduLib.edtInputApplyAll(apd, tagDlg); //화면에 입력한 값이 value로 지정한 mi에 설정된다.
		
		for(var i = 0; i < mi.length;i++) {
			if(mi[i].subtitle_en.size)
				mi[i].subtitle_en.name = 'subtitle_en_'+i+'.smi';
			else
				mi[i].subtitle_en.name = '';

			if(mi[i].subtitle_ko.size)
				mi[i].subtitle_ko.name = 'subtitle_ko_'+i+'.smi';
			else
				mi[i].subtitle_ko.name = '';
		}

		apd.wgtSetProperty(objID, 'p_cfg', cfg);
		apd.wgtSetProperty(objID, 'mi', mi);
	}

	if (tagDlg = apd.dlgDoModal(800, 400, onOK))
	{
		eduLib.edtInputAdd(apd, tagDlg, {type:'select', value:cfg, options:[{value:'chomokdal', title:'초목달'}, {value:'sang', title:'생수다'}], title:'UI Skin', key:'skin'});
		eduLib.edtInputAdd(apd, tagDlg, {type:'table', value:mi,
			options:{th:[ '미디어 순번','시험URL','한글자막','영문자막'], add:true, remove:true},
					 td:[{type:'number',key:'media_index',width:'70px'},{type:'text',key:'test_url',width:'420px'},{type:'file',accept:'.smi,.vtt',key:'subtitle_ko',width:'120px'},{type:'file',accept:'.smi,.vtt',key:'subtitle_en',width:'120px'}]});
	}
}

xa.edtOnBuildState = function(prj, oId, pageID, ret)
{
	for(var i in apn.widgets['ebs.wgt.video'].editor.states){
		ret[i] = apn.widgets['ebs.wgt.video'].editor.states[i];
	}

	var cData = prj.pages[pageID].objects[oId].create.data;

	if (cData && cData.properties && cData.properties.attrs && cData.properties.attrs.mi && cData.properties.attrs.mi.length > 1){
		for(var i = 0; i < cData.properties.attrs.mi.length; i++) {
			ret['PT_'+(i+1)] = 'PlayTrack '+(i+1);
		}
	}
}

xa.edtOnBuildEvent = function(prj, oId, pageID, ret)
{
	ret.wgtEvent = {value:'wgtEvent', /*title:'Zone Player Event', */ param:{}};
	//%%INFO: ret.wgtEvent.param['%Name used in fireEvent%'] = %Event parameter when scripting';
	ret.wgtEvent.param['Seeked'] = 'Seeked';
	ret.wgtEvent.param['End'] = 'End';
	ret.wgtEvent.param['RPT_TIME'] = 'ReportUsageTime';
	ret.wgtEvent.param['Played'] = 'Played';
	ret.wgtEvent.param['Tapped'] = 'Tapped';
	
	var cData = prj.pages[pageID].objects[oId].create.data;
	if (cData && cData.properties && cData.properties.attrs && cData.properties.attrs.mi && cData.properties.attrs.mi.length > 1){
		for(var i = 0; i < cData.properties.attrs.mi.length; i++) {
			ret.wgtEvent.param['TCD_'+(i+1)] = 'TrackChanged'+(i+1);
		}
	}
	//ret.media = {value:'media', title:apn.P.eventTitle.media, param:{Start:'Start',Pause:'Pause',End:'End',Seek:'Seek'}};
}

ebsWgtVideo = xa;
